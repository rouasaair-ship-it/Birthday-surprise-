A LITTLE UNIVERSE OF YOU — RESPONSIVE STARTER WEBSITE

Works on:
- Windows laptops using Chrome, Edge, or Firefox.
- Android phones using Chrome or another modern browser.

No app installation, paid account, payment card, external fonts, APIs, or subscription is needed to preview it.

PREVIEW ON ANDROID:
1. Download the ZIP file.
2. Open it in your Files app and extract it.
3. Find birthday-universe/index.html.
4. Tap it and choose Chrome if Android offers a browser choice.
   If your file manager does not open local HTML files, use the free GitHub Pages publishing steps below when ready.

PREVIEW ON WINDOWS:
1. Extract the ZIP.
2. Double-click index.html.
3. It opens in your default browser (Chrome or Edge recommended).

CUSTOMIZE:
Search index.html for square-bracket prompts such as [Add a screenshot...] and replace them with your own details. Replace [Your name / nickname] on the final page too.

FREE ONLINE HOSTING:
When you're ready, create a public GitHub repository, upload index.html to the repository root, then enable Pages in Settings > Pages. GitHub provides a shareable URL. Do not put private or sensitive conversations in a public repository.
